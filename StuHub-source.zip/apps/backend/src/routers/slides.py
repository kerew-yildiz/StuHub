"""Chapter guide slides — yükleme + çıkarım + listeleme (Faz 2.1)."""

from __future__ import annotations

import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from ..auth import get_tenant_id
from ..config import settings
from ..db import get_db
from ..services import indexer, pdf_service, slides_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["slides"])

ALLOWED_EXTENSIONS = {".pdf", ".pptx", ".ppt"}


class SlideOut(BaseModel):
    id: int
    chapter_id: int
    material_id: int | None
    slide_no: int
    content_text: str | None


@router.post("/chapters/{chapter_id}/slides", response_model=list[SlideOut], status_code=201)
async def upload_guide_slides(
    chapter_id: int,
    file: UploadFile = File(...),
    tenant_id: str = Depends(get_tenant_id),
) -> list[SlideOut]:
    """Chapter için guide slides yükler; slide içeriklerini çıkarıp `slides`'a yazar.

    - Dosya `materials`'a type='slides' olarak kaydedilir (course_id chapter'dan alınır).
    - PDF → pymupdf sayfa bazlı; PPTX → python-pptx slide bazlı çıkarım.
    - LibreOffice varsa PPTX→PDF render kopyası üretilir (pop-up için); yoksa metin
      alıntısı fallback'i kullanılır (yol haritası 2.1 + Yetenek 01).
    """
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=422, detail="Desteklenen uzantılar: PDF, PPTX")
    content = await file.read()
    if not content:
        raise HTTPException(status_code=422, detail="Boş dosya yüklenemez")

    db = await get_db()
    try:
        cursor = await db.execute(
            "SELECT course_id FROM chapters WHERE id = ? AND tenant_id = ?",
            (chapter_id, tenant_id),
        )
        chapter = await cursor.fetchone()
        if chapter is None:
            raise HTTPException(status_code=404, detail="Chapter bulunamadı")
        course_id = chapter["course_id"]

        safe_name = Path(file.filename or "dosya").name.replace("/", "_").replace("\\", "_")
        course_dir = settings.materials_dir / str(course_id)
        course_dir.mkdir(parents=True, exist_ok=True)
        stored_name = f"{uuid.uuid4().hex}_{safe_name}"
        dest = course_dir / stored_name
        dest.write_bytes(content)

        cursor = await db.execute(
            "INSERT INTO materials (tenant_id, course_id, type, filepath) "
            "VALUES (?, ?, 'slides', ?)",
            (tenant_id, course_id, str(dest)),
        )
        await db.commit()
        material_id = cursor.lastrowid
        if material_id is None:
            raise RuntimeError("materyal kimliği alınamadı")

        # PPTX → PDF render kopyası (pop-up görüntüleme; LibreOffice yoksa None)
        if ext in (".pptx", ".ppt"):
            render_dir = settings.materials_dir / str(course_id) / "renders"
            slides_service.render_pptx_to_pdf(str(dest), str(render_dir))

        if ext in (".pptx", ".ppt"):
            try:
                extracted = slides_service.extract_pptx_slides(str(dest))
            except slides_service.SlidesError as exc:
                raise HTTPException(status_code=422, detail=str(exc)) from exc
        else:
            try:
                pages = pdf_service.extract_pdf_pages(str(dest))
            except pdf_service.PdfError as exc:
                raise HTTPException(status_code=422, detail=str(exc)) from exc
            extracted = [{"slide": p["page"], "text": p["text"]} for p in pages]

        # İkinci bir sunum yüklendiğinde slide_no 1'den başlamasın — mevcut destenin
        # devamından numaralansın (birden fazla deste sorunsuz birleşir).
        cursor = await db.execute(
            "SELECT COALESCE(MAX(slide_no), 0) AS max_no FROM slides "
            "WHERE chapter_id = ? AND tenant_id = ?",
            (chapter_id, tenant_id),
        )
        offset_row = await cursor.fetchone()
        offset = offset_row["max_no"] if offset_row is not None else 0

        out: list[SlideOut] = []
        for slide_data in extracted:
            slide_no = slide_data["slide"] + offset
            cursor = await db.execute(
                "INSERT INTO slides (tenant_id, chapter_id, material_id, slide_no, content_text) "
                "VALUES (?, ?, ?, ?, ?)",
                (tenant_id, chapter_id, material_id, slide_no, slide_data["text"]),
            )
            await db.commit()
            slide_id = cursor.lastrowid
            if slide_id is None:
                raise RuntimeError("slide kimliği alınamadı")
            out.append(
                SlideOut(
                    id=slide_id,
                    chapter_id=chapter_id,
                    material_id=material_id,
                    slide_no=slide_no,
                    content_text=slide_data["text"],
                )
            )
        try:
            await indexer.maybe_start_auto_notes(course_id, tenant_id)
        except Exception:
            logger.exception("otomatik not tetikleme başarısız: course=%s", course_id)
        return out
    finally:
        await db.close()


@router.get("/chapters/{chapter_id}/slides", response_model=list[SlideOut])
async def list_slides(chapter_id: int, tenant_id: str = Depends(get_tenant_id)) -> list[SlideOut]:
    """Bir chapter'ın guide slide'larını sıralı döner."""
    db = await get_db()
    try:
        cursor = await db.execute(
            "SELECT id, chapter_id, material_id, slide_no, content_text FROM slides "
            "WHERE chapter_id = ? AND tenant_id = ? ORDER BY slide_no ASC",
            (chapter_id, tenant_id),
        )
        rows = await cursor.fetchall()
    finally:
        await db.close()
    return [SlideOut(**dict(r)) for r in rows]


@router.delete("/slides/{slide_id}", status_code=204)
async def delete_slide(slide_id: int, tenant_id: str = Depends(get_tenant_id)) -> None:
    """Tek slide'ı siler."""
    db = await get_db()
    try:
        cursor = await db.execute(
            "DELETE FROM slides WHERE id = ? AND tenant_id = ?", (slide_id, tenant_id)
        )
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Slide bulunamadı")
        await db.commit()
    finally:
        await db.close()
