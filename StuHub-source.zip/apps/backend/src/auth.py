"""SaaS kimlik doğrulama — Supabase JWT doğrulama + kiracı kimliği çözümü.

Yerel/test modunda (`settings.saas_mode` False, yani `DATABASE_URL` boş) auth yok:
sabit `LOCAL_TENANT_ID` kullanılır, bugünkü tek-kullanıcı davranışı birebir korunur
(KARAR-SAAS-GECISI.md soru 1/7 — yerel sürüm auth'suz kalır).

SaaS modunda her istek `Authorization: Bearer <supabase-access-token>` taşımak
zorundadır. İmza doğrulaması iki yolu destekler:
- **Yeni projeler (varsayılan, ES256/JWKS):** Supabase artık access token'ları asimetrik
  anahtarla imzalıyor; `SUPABASE_URL`den türetilen `{url}/auth/v1/.well-known/jwks.json`
  uç noktasından açık anahtar çekilir (`jwt.PyJWKClient`, önbellekli).
- **Eski projeler (Legacy JWT Secret, HS256):** `SUPABASE_JWT_SECRET` ayarlıysa ve JWKS
  yoksa/başarısızsa buna düşülür.
`sub` claim'i `tenant_id` (Supabase `auth.users.id`, uuid) olarak kullanılır. İlk geçerli
istekte `profiles` tablosuna otomatik bir satır açılır (auto-provision) — Supabase Auth
kullanıcı kaydını kendi yönetir, uygulama yalnızca profil/plan satırını senkron tutar.

`require_admin`: `/api/settings` gibi kiracıya özel OLMAYAN, operatör-seviyeli
uçlar için (bkz. schema_postgres.sql `settings` tablosu yorumu). Yerel modda
her istek admin sayılır; SaaS modunda yalnızca `profiles.is_admin = true`.
"""

from __future__ import annotations

import asyncio

import jwt
from fastapi import Header, HTTPException

from .config import settings
from .db import get_db

LOCAL_TENANT_ID = "local"

# Supabase access token'ları bu audience ile imzalanır (GoTrue varsayılanı).
_JWT_AUDIENCE = "authenticated"

_jwk_client: jwt.PyJWKClient | None = None

# `_ensure_profile` idempotent bir INSERT ... ON CONFLICT DO NOTHING'dir — ama JWT
# doğrulandıktan sonra HER istekte çalıştırılıyordu, yani her tek API çağrısına gereksiz
# bir tam Postgres round-trip'i (~200-250ms, 2026-09-05 perf turunda ölçüldü) ekliyordu.
# Bir kiracı için satır bir kez açıldıktan sonra bu adımın tekrarına gerek yok; süreç
# ömrü boyunca "zaten sağlandı" kümesi tutulur (yalnızca doğrulanmış JWT'lerden gelen
# gerçek kiracı kimlikleri girer, kullanıcı girdisi değildir — güvenlik riski yok).
_provisioned: set[str] = set()


class AuthError(HTTPException):
    def __init__(self, detail: str, status_code: int = 401) -> None:
        super().__init__(status_code=status_code, detail=detail)


def _get_jwk_client(*, fresh: bool = False) -> jwt.PyJWKClient | None:
    """JWKS istemcisini döner (tembel singleton). `fresh=True`: önbelleği atlayıp
    yeni bir istemci kurar — bkz. `_decode_token` soğuk-önbellek yeniden deneme notu."""
    global _jwk_client
    if not settings.supabase_url:
        return None
    if _jwk_client is None or fresh:
        jwks_url = settings.supabase_url.rstrip("/") + "/auth/v1/.well-known/jwks.json"
        _jwk_client = jwt.PyJWKClient(jwks_url, cache_keys=True, lifespan=3600)
    return _jwk_client


def _decode_with_jwks(token: str, jwk_client: jwt.PyJWKClient) -> dict:
    signing_key = jwk_client.get_signing_key_from_jwt(token)
    return jwt.decode(
        token,
        signing_key.key,
        algorithms=["ES256", "RS256"],
        audience=_JWT_AUDIENCE,
    )


def _decode_token(token: str) -> dict:
    jwk_client = _get_jwk_client()
    if jwk_client is not None:
        try:
            return _decode_with_jwks(token, jwk_client)
        except jwt.ExpiredSignatureError as exc:
            # Süresi dolmuş token YENİ imza anahtarı gerektirmez; JWKS'i tazelemek boşuna
            # bir ağ turudur ve istemci token'ı yenileyene kadar HER istekte tekrarlanır.
            raise AuthError("Oturum geçersiz veya süresi dolmuş.") from exc
        except jwt.PyJWTError:
            # İlk deneme başarısız — 2026-09-08 canlı bulgu: taze imzalanmış bir token,
            # önbellekteki JWKS anahtar setinde henüz yoksa (soğuk önbellek/anahtar
            # rotasyonu) burada başarısız olup kullanıcıya "geçersiz oturum" gösteriyordu;
            # oysa sayfa yenilendiğinde (yeni bir istek → önbellek o sırada ısınmış oluyor)
            # AYNI token sorunsuz doğrulanıyordu. Düzeltme: önbelleği atlayıp bir kez daha
            # dene — bu, kullanıcının yenilemeyle elde ettiği sonucu tek istekte verir.
            try:
                fresh_client = _get_jwk_client(fresh=True)
                if fresh_client is not None:
                    return _decode_with_jwks(token, fresh_client)
            except jwt.PyJWTError as exc:
                if not settings.supabase_jwt_secret:
                    raise AuthError("Oturum geçersiz veya süresi dolmuş.") from exc
                # JWKS iki denemede de başarısız (ör. eski proje, henüz asimetrik
                # anahtara geçmemiş) — Legacy HS256 sırra düş.
    if not settings.supabase_jwt_secret:
        raise AuthError(
            "Sunucu SaaS auth için yapılandırılmamış (VITE_SUPABASE_URL/SUPABASE_JWT_SECRET eksik)."
        )
    try:
        return jwt.decode(
            token,
            settings.supabase_jwt_secret,
            algorithms=["HS256"],
            audience=_JWT_AUDIENCE,
        )
    except jwt.PyJWTError as exc:
        raise AuthError("Oturum geçersiz veya süresi dolmuş.") from exc


async def _ensure_profile(tenant_id: str, email: str) -> None:
    """Profil satırı yoksa açar (varsayılan plan: free). Var olanı değiştirmez."""
    db = await get_db()
    try:
        await db.execute(
            "INSERT INTO profiles (id, email) VALUES (?, ?) "
            "ON CONFLICT (id) DO NOTHING",
            (tenant_id, email),
        )
        await db.commit()
    finally:
        await db.close()


async def _fetch_profile(tenant_id: str) -> dict | None:
    db = await get_db()
    try:
        cursor = await db.execute(
            "SELECT id, email, plan, is_admin FROM profiles WHERE id = ?", (tenant_id,)
        )
        row = await cursor.fetchone()
        return dict(row) if row else None
    finally:
        await db.close()


async def get_tenant_id(authorization: str | None = Header(default=None)) -> str:
    """İstek sahibinin kiracı kimliğini döner; SaaS modunda JWT doğrular ve
    profili otomatik açar. Yerel modda her zaman `LOCAL_TENANT_ID` döner."""
    if not settings.saas_mode:
        return LOCAL_TENANT_ID
    if not authorization or not authorization.startswith("Bearer "):
        raise AuthError("Oturum açmanız gerekiyor.")
    token = authorization.removeprefix("Bearer ").strip()
    # `_decode_token` senkron ağ I/O yapabilir (JWKS çekimi, ~250-900ms): event loop'ta
    # çalıştırılırsa TÜM backend durur (6 eşzamanlı istekte /health 2ms → 1243ms ölçüldü).
    payload = await asyncio.to_thread(_decode_token, token)
    tenant_id = payload.get("sub")
    if not tenant_id:
        raise AuthError("Oturum geçersiz.")
    if tenant_id not in _provisioned:
        await _ensure_profile(tenant_id, payload.get("email", ""))
        _provisioned.add(tenant_id)
    return tenant_id


async def require_admin(authorization: str | None = Header(default=None)) -> str:
    """`/api/settings` gibi operatör uçları için: yerel modda serbest, SaaS
    modunda yalnızca `profiles.is_admin = true` olan kiracı."""
    tenant_id = await get_tenant_id(authorization)
    if not settings.saas_mode:
        return tenant_id
    profile = await _fetch_profile(tenant_id)
    if profile is None or not profile.get("is_admin"):
        raise AuthError("Bu uç yalnızca yönetici erişimine açık.", status_code=403)
    return tenant_id
